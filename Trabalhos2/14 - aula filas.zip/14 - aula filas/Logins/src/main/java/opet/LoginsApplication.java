package opet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginsApplication.class, args);
	}

}
